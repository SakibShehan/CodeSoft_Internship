/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atm;

import java.io.*;


/**
 *
 * @author Shehan
 */
public class BankAccount {
    
    String AccountNo="11223344";
    int balance=0;
    private static final String FILE_NAME = "balance.txt";
    
     public BankAccount() {
        loadBalance();
    }

    public void loadBalance() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line = reader.readLine();
            if (line != null) {
                balance = Integer.parseInt(line);
            }
        } catch (IOException | NumberFormatException e) {
            balance = 0; // fallback if file doesn't exist or is invalid
        }
    }

    public void saveBalance() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            writer.write(String.valueOf(balance));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
