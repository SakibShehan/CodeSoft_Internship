import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    static String grade(int marks)
    {
        if(marks>=80)return "A+";
        else if(marks>=70) return "A";
        else if(marks>=60) return "A-";
        else if(marks>=50) return "B";
        else if(marks>=40) return "C";
        else if(marks>=33) return "D";
        else return "fail";

    }

    static double gradepoint(int marks)
    {
        if(marks>=80)return 5.00 ;
        else if(marks>=70) return 4.00;
        else if(marks>=60) return 3.5;
        else if(marks>=50) return 3.00;
        else if(marks>=40) return 2.00;
        else if(marks>=33) return 1.00;
        else return 0.00;
    }
    public static void main(String[] args) {

        System.out.println("Welcome to Grade Calculator");
        System.out.println("Enter number of each subject:");

        Scanner sc= new Scanner(System.in);
        int totalmarks=0,bangla,english,math,physics,chemistry,biology,ict;
        double gp=0.0;

        System.out.print("Enter number of Bangla");
        bangla=sc.nextInt();
        totalmarks+=bangla;
        gp+=gradepoint(bangla);
        System.out.println();

        System.out.print("Enter number of English");
        english=sc.nextInt();
        totalmarks+=english;
        gp+=gradepoint(english);
        System.out.println();

        System.out.print("Enter number of Mathematics");
        math=sc.nextInt();
        totalmarks+=math;
        gp+=gradepoint(math);
        System.out.println();

        System.out.print("Enter number of Physics");
        physics=sc.nextInt();
        totalmarks+=physics;
        gp+=gradepoint(physics);
        System.out.println();

        System.out.print("Enter number of Chemistry");
        chemistry=sc.nextInt();
        totalmarks+=chemistry;
        gp+=gradepoint(chemistry);
        System.out.println();

        System.out.print("Enter number of Biology");
        biology=sc.nextInt();
        totalmarks+=biology;
        gp+=gradepoint(biology);
        System.out.println();

        System.out.print("Enter number of ICT");
        ict=sc.nextInt();
        totalmarks+=ict;
        gp+=gradepoint(ict);
        System.out.println();

        System.out.println("Your Total Marks:"+ totalmarks);
        System.out.println("Your Average Marks:"+ totalmarks/7);
        System.out.println("Your GPA is:"+ gp/7);

        System.out.println("Your Grade in Bangla:"+ grade(bangla));
        System.out.println("Your Grade in English:"+ grade(english));
        System.out.println("Your Grade in Mathematics:"+ grade(math));
        System.out.println("Your Grade in Physics:"+ grade(physics));
        System.out.println("Your Grade in Chemistry:"+ grade(chemistry));
        System.out.println("Your Grade in Biology:"+ grade(biology));
        System.out.println("Your Grade in ICT:"+ grade(ict));
        }

}