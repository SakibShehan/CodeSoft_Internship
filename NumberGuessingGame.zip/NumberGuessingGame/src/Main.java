import java.util.Scanner;

public class Main {



    static void game()
    {

        Scanner sc=new Scanner(System.in);

       System.out.println("Welcome to Number Game");

       while(true)
       {
           System.out.println("A number is generated! Guess it");


           int k= 1+ (int) (100*Math.random());
           int flag=0;
           //System.out.println("Actual Number is:"+k);
           for(int i=1;i<=5;i++)
           {
               int s=sc.nextInt();

               if(s==k)
               {
                   System.out.println("Woww! Your assumption is Correct");
                   System.out.println("Your Score "+ (5-i+1));
                   flag =1;
                   break;
               }
               else if(s-k>=20)System.out.print("Too high. ");
               else if(k-s>=20)System.out.print("Too low. ");
               else if((s-k<=20 && s-k>10)|| (k-s<=20 && k-s>10))System.out.println("close.");
               else System.out.print("Very close. ");

               if(i<=4)System.out.println("Try again");
           }
           System.out.println();
           if(flag==0)System.out.println("You lost! Score 0");
           System.out.println("Actual Number is:"+k);
           System.out.println("Wanna Play again? ");
           System.out.println("Press 1 for Play again");
           System.out.println("Press 2 for Exit");

           int choice = sc.nextInt();

           if(choice==2)
           {
               System.out.println("Bye! See You very soon..");
               break;
           }
       }

    }



    public static void main(String[] args) {
         game();
    }
}